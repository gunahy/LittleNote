package com.lesson1.android2.littlenote;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import com.lesson1.android2.littlenote.db.AppDB;

public class DealElement extends AppCompatActivity implements Initialable{

    private Toolbar toolbar;
    private TextView tvTitleNote, tvDescNote, tvDateNote, tvMap;
    private String nTitle, nDesc, nDate, nCoord, nUserID;
    private Intent intent;
    private AppDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deal_element);

        initViews();
        intent = getIntent();

        setViewsNoteValue(intent);
        setSupportActionBar(toolbar);
    }

    @Override
    public void initViews() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        tvTitleNote = (TextView)findViewById(R.id.etTitleNote);
        tvDescNote = (TextView)findViewById(R.id.etDescNote);
        tvDateNote = (TextView)findViewById(R.id.etDateNote);
        tvMap = (TextView)findViewById(R.id.etMap);
    }

    @Override
    public void initDB() {
        db = new AppDB(this);
        db.openConnection(false);
    }

    @Override
    public void initListView() {

    }

    private void setViewsNoteValue(Intent intent){

        int noteID = (int)intent.getExtras().get(COL__ID);
        int userID = (int)intent.getExtras().get(COL_USERID);
        db.getUserNote(userID, noteID);

    }


}
