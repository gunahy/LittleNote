package com.lesson1.android2.littlenote;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.lesson1.android2.littlenote.db.AppDB;

public class EditDeal extends AppCompatActivity implements Initialable {

    private AppDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_deal);
    }

    public void saveNote(View view) {


    }

    @Override
    public void initViews() {

    }

    @Override
    public void initDB() {
        db = new AppDB(this);
        db.openConnection(false);

    }

    @Override
    public void initListView() {

    }
}
